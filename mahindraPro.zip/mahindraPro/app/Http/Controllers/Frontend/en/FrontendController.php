<?php

namespace App\Http\Controllers\Frontend\en;

use App\Models\Car;
use App\Models\Feature;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\DealerLocator;
use App\Http\Controllers\Controller;

class FrontendController extends Controller
{
    //العرض يكون في الصفحة الرئيسية
    public function index()
    {
        return view('frontend.en.index');
    }
    //عرض صفحة معلومات عن الشركة
    public function about()
    {
        return view('frontend.en.about');
    }

    //عرض صفحة تواصل معنا
    public function contact()
    {
        return view('frontend.en.contact');
    }

    //العرض يكون في الصفحة الرئيسية
    public function dealerlocator()
    {

        $dealerlocators = DealerLocator::where('language_id', 2)->orderBy('id', 'DESC')->get(); //عرض ناقل الحركة
        if ($dealerlocators) {

            return view('frontend.en.dealerlocator', [
                'dealerlocators' => $dealerlocators,
            ]);
        } else {
            return redirect()->back();
        }
    }


    //صفحة عرض السيارات
    public function vehicles()
    {
        $cars = Car::where('language_id', 2)->orderBy('id', 'DESC')->get(); //عرض ناقل الحركة
        if ($cars) {

            return view('frontend.en.vehicles', [
                'cars' => $cars,
            ]);
        } else {
            return redirect()->back();
        }
    }

    public function viewCategory($car_id)
    {
        $category = Category::where('car_id', $car_id)->where('language_id', 2)->first(); //جلب البيانات من جدول category بحسب رقم id

        if ($category) {

            $categories = Category::where('car_id', $car_id)->where('language_id', 2)->get(); //جلب البيانات من جدول category بحسب رقم id
            $features = Feature::where('category_id', $category->id)->where('language_id', 2)->get();


            return view('frontend.en.viewCategory', [
                'categories' => $categories,
                'features' => $features
            ]);
        } else {
            return redirect()->back();
        }
    }
    //عرض معلومات السيارة المحددة
    public function VehiclesDetail($category_id)
    {
        $category = Category::where('id', $category_id)->where('language_id', 2)->first(); //جلب البيانات من جدول category بحسب رقم id
        if ($category) {

            // $categories = Category::where('car_id', $car_id)->get();

            //جلب المواصفات المرتبطة بالفئة المددة
            $feature = Feature::where('category_id', $category->id)->where('language_id', 2)->first();
            if ($feature) {

                return view('frontend.en.VehiclesDetail', [
                    'category' => $category,
                    'feature' => $feature,
                    // 'categories' => $categories
                ]);
            } else {
                return redirect()->back();
            }
        }
    }
}

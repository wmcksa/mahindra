<?php

namespace App\Filament\Resources\DealerLocatorResource\Pages;

use App\Filament\Resources\DealerLocatorResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDealerLocator extends CreateRecord
{
    protected static string $resource = DealerLocatorResource::class;
}

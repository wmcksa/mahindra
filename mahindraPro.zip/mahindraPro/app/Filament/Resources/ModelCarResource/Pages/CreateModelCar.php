<?php

namespace App\Filament\Resources\ModelCarResource\Pages;

use App\Filament\Resources\ModelCarResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateModelCar extends CreateRecord
{
    protected static string $resource = ModelCarResource::class;
}

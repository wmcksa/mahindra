<?php

namespace App\Filament\Resources\DrivingTestResource\Pages;

use App\Filament\Resources\DrivingTestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDrivingTest extends CreateRecord
{
    protected static string $resource = DrivingTestResource::class;
}

<?php

namespace App\Filament\Resources\MotionVactorResource\Pages;

use App\Filament\Resources\MotionVactorResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMotionVactor extends CreateRecord
{
    protected static string $resource = MotionVactorResource::class;
}

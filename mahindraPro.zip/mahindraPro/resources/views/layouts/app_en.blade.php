<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title> @yield('title')</title>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="keywords" />
    <meta name="description" />

    <!--Bootstrap -->

    <link rel="stylesheet" href="{{asset('assets/en/assets/css/bootstrap.min.css')}}" type="text/css" />

    <!--Custome Style -->

    <link rel="stylesheet" href="{{asset('assets/en/assets/css/style.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('assets/en/assets//css/custom.css')}}" type="text/css" />


    <!--OWL Carousel slider-->

    <link rel="stylesheet" href="{{asset('assets/en/assets/css/owl.carousel.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('assets/en/assets/css/owl.transitions.css')}}" type="text/css" />
    <!--slick-slider -->

    <link href="{{asset('assets/en/assets/css/slick.css')}}" rel="stylesheet" />

    <!--bootstrap-slider -->

    <link href="{{asset('assets/en/assets/css/bootstrap-slider.min.css')}}" rel="stylesheet" />

    <!--FontAwesome Font Style -->

    <link href="{{asset('assets/en/assets/css/fontawesome.min.css')}}" rel="stylesheet" />



    <!-- SWITCHER -->

    <link rel="stylesheet" type="text/css" href="{{asset('assets/en/assets/switcher/css/switcher.css')}}" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="{{asset('assets/en/assets/switcher/css/red.css')}}"
        title="red" media="all" data-default-color="true" />
    <link rel="alternate stylesheet" type="text/css" href="{{asset('assets/en/assets/switcher/css/orange.css')}}"
        title="orange" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="{{asset('assets/en/assets/switcher/css/blue.css')}}"
        title="blue" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="{{asset('assets/en/assets/switcher/css/pink.css')}}"
        title="pink" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="{{asset('assets/en/assets/switcher/css/green.css')}}"
        title="green" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="{{asset('assets/en/assets/switcher/css/purple.css')}}"
        title="purple" media="all" />



    <!-- Fav and touch icons -->

    <link rel="shortcut icon" href="{{asset('assets/en/assets/images/logo/favicon-48x48.ico')}}" />

    <!-- Google-Font-->

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

<![endif]-->

    <link href="{{asset('assets/en/assets/App_Themes/Theme_En/Theme_En.css')}}" type="text/css" rel="stylesheet" />
    @livewireStyles
</head>

<body class="index2">

    <div id="app">

        <main>
            @yield('content')
        </main>
    </div>







    <!-- Scripts -->

    <script src="{{asset('assets/en/assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('assets/en/assets/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('assets/en/assets/js/interface.js')}}"></script>

    <script src="{{asset('assets/en/assets/js/31f5977fdc.js')}}"></script>

    <!--Switcher-->

    <script src="{{asset('assets/en/assets/switcher/js/switcher.js')}}"></script>

    <!--bootstrap-slider-JS-->

    <script src="{{asset('assets/en/assets/js/bootstrap-slider.min.js')}}"></script>

    <!--Slider-JS-->

    <script src="{{asset('assets/en/assets/js/slick.min.js')}}"></script>

    <script src="{{asset('assets/en/assets/js/owl.carousel.min.js')}}"></script>

    <script>
        //$(document).ready(function () {
        //    debugger;
        //    var loadTime = new Date();
        //    $(document).mouseleave(function () {
        //        var leaveTime = new Date();
        //        var diff = leaveTime - loadTime;
        //        var sec = diff / 1000;
        //        if (sec > 10) {
        //            $('#signupform').addClass("show");
        //            $('#signupform').attr('aria-modal', 'true');
        //            $('#signupform').attr('role', 'dialog');
        //            $('#signupform').css('display', 'block');
        //            $('body').addClass('modal-open');
        //            $('body').css('overflow', 'hidden');
        //            $('body').css('padding-right', '17px');
        //            $('body').append('<div class="modal-backdrop fade show"></div>');

        //        }
        //        loadTime = new Date();
        //    });

        //});
    </script>
    @livewireScripts
</body>


</html>
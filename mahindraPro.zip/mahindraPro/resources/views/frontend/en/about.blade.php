@extends('layouts.app_en')

@section('title','About Page')
@section('content')


<div class="page-wrapper">


    <!--Header-->

    @include('layouts.includes.frontend.en.nav')

    <!-- /Header -->


    <section>

        <!--Page Header-->
        <section class="page-header aboutus_page1" style="background-image: url(assets/images/newimage/About.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">About Us</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="index.php">
                                <span id="ContentPlaceHolder_lblHomeHeader">Home</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2"></span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->

        </section>
        <!-- /Page Header-->

        <!--About-us-->

        <!-- /About-us-->

        <!-- Why-Choose-Us-->
        <section class="why_choose_us section-padding gray-bg">
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="title">Why <span>mahindra</span></h2>
                    <p class="body">
                        <span id="ContentPlaceHolder_lblWhydesc">
                            <font color="#726d7b" face="DM Sans, sans-serif"><span style="font-size: 18px;">The
                                    Mahindra Group is a global consortium of companies that empowers people to
                                    advance and develop through innovative solutions designed to deliver a unique
                                    modern mobility experience, nurture new businesses and enhance communities. In
                                    1945, Mahindra's journey began, and 75 years later it has expanded to cover 23
                                    major industries. Mahindra is a leader in utility vehicles, information
                                    technology, financial services and vacation ownership in India and is the
                                    world's largest tractor company by volume. Headquartered in India, Mahindra's
                                    network employs more than 250,000 people in 100 countries around the
                                    world.</span></font>
                        </span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="listing_box">
                            <h5><i class="fa fa-user-circle" aria-hidden="true"></i>
                                <span id="ContentPlaceHolder_lblTrustedByThousands">Trusted By Thousands</span>
                            </h5>
                            <p class="body">
                                <span id="ContentPlaceHolder_lblTrustedByThousandsdesc">After purchasing Mahindra
                                    cars, you can maintain them and ensure their safety at any time by visiting the
                                    company</span>
                            </p>
                        </div>
                        <div class="listing_box">
                            <h5><i class="fa fa-globe" aria-hidden="true"></i>
                                <span id="ContentPlaceHolder_lblWideRangeOfVehicles">Wide Range Of features in
                                    vehicles</span>
                            </h5>
                            <p class="body">
                                <span id="ContentPlaceHolder_lblWideRangeOfVehiclesdesc">With Mahindra, you can
                                    enjoy all the stunning scenery and live the adventure wherever your path takes
                                    you!</span>

                            </p>
                        </div>
                        <div class="listing_box">
                            <h5><i class="fa fa-car" aria-hidden="true"></i>
                                <span id="ContentPlaceHolder_lblFasterBuySell">Aftersales Support</span>
                            </h5>
                            <p class="body">
                                <span id="ContentPlaceHolder_lblFasterBuySelldesc">With the increasing desire to own
                                    premium cars and the increasing demand for our products, you can easily buy and
                                    sell them</span>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="video_box">
                            <iframe class="mfp-iframe" src="https://www.youtube.com/embed/3Zsyy3JjZME"
                                allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /Why-Choose-Us-->





    </section>
    <!-- main-container -->


    <!--Footer -->

    @include('layouts.includes.frontend.en.footer1')

    <!-- /Footer-->





</div>


@endsection
@extends('layouts.app_en')

@section('title','About Page')
@section('content')



<div class="page-wrapper">




    <!--Header-->
    @include('layouts.includes.frontend.en.nav')


    <!-- /Header -->


    <section>


        <!--Page Header-->
        <section class="page-header contactus_page" style="background-image: url(assets/images/newimage/Contact.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">Contact Us</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="i{{url('/home-en')}}">
                                <span id="ContentPlaceHolder_lblHomeHeader">Home</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">Contact Us</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->
            <div class="dark-overlay"></div>
        </section>
        <!-- /Page Header-->

        <!--Contact-us-->

        <livewire:frontend.en.vehicles-detail.contact />


        <!-- /Contact-us-->

        <!--Brands-->

        <!-- /Brands-->


    </section>
    <!-- main-container -->


    <!--Footer -->

    @include('layouts.includes.frontend.en.footer1')


    <!-- /Footer-->




</div>

@endsection
@extends('layouts.app')

@section('title','Contact Us Page')
@section('content')



<div class="page-wrapper">
    <!--Header-->
    @include('layouts.includes.frontend.nav')
    <!-- /Header -->


    <section>

        <!--Page Header-->
        <section class="page-header contactus_page" style="background-image: url(assets/images/newimage/Contact.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">اتصل بنا</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="{{url('/')}}">
                                <span id="ContentPlaceHolder_lblHomeHeader">الصفحة الرئيسية</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">اتصل بنا</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->
            <div class="dark-overlay"></div>
        </section>
        <!-- /Page Header-->

        <!--Contact-us-->

        <livewire:frontend.vehicles-detail.contact />
        <!-- /Contact-us-->

        <!--Brands-->

        <!-- /Brands-->


    </section>
    <!-- main-container -->

    <!--Footer -->
    @include('layouts.includes.frontend.footer1')

    <!-- /Footer-->




</div>

@endsection
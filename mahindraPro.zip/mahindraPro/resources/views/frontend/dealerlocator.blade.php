@extends('layouts.app')

@section('title','Dealer Locator Page')
@section('content')


<div class="page-wrapper">

    <!--Header-->
    @include('layouts.includes.frontend.nav')
    <!-- /Header -->


    <section>



        <!--Page Header-->
        <section class="page-header aboutus_page"
            style="background-image: url(assets/images/newimage/DealerLocator.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">فروعنا</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="{{url('/')}}">
                                <span id="ContentPlaceHolder_lblHomeHeader">الصفحة الرئيسية</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">فروعنا</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->

        </section>
        <!-- /Page Header-->

        <!--Contact-us-->
        <section class="contact_us section-padding">
            <div class="container">

                <div class="row">
                    <div class="col-md-6">
                        <h3 class="title">
                            <span id="ContentPlaceHolder_lblMahindra">ماهيندرا</span>
                        </h3>
                        <div class="contact_form gray-bg">
                            @forelse ($dealerlocators as $dealerlocator)
                            <ul style="list-style: none;" class="body">
                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lbladdress1">
                                            {{$dealerlocator->country}}
                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="contact_info_m">
                                        {{$dealerlocator->city}}
                                    </div>
                                </li>
                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lbladdress2">
                                            {{$dealerlocator->location}}
                                        </span>
                                    </div>
                                </li>
                                {{-- <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lbladdress3">المملكة العربية السعودية</span>
                                    </div>
                                </li> --}}
                                <li>
                                    <div class="contact_info_m">

                                        <span id="ContentPlaceHolder_lblSun">
                                            أيام العمل
                                            {{$dealerlocator->beginning_working_day}}
                                            الى
                                            {{$dealerlocator->end_working_day}}

                                        </span>
                                    </div>
                                </li>

                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lblSatCLOSED">

                                            ساعات العمل
                                            {{$dealerlocator->beginning_working_hours}}
                                            الى
                                            {{$dealerlocator->end_working_hours}}
                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="contact_info_m"><a href="{{$dealerlocator->mobile}}">
                                            {{$dealerlocator->mobile}}
                                        </a></div>
                                </li>

                            </ul>

                            @empty

                            <div>
                                <h2>لا يوجد فروع </h2>
                            </div>
                            @endforelse
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="contact_detail">
                            <div class="map_wrap">
                                <div class="mapouter">
                                    <iframe class="gmap_iframe" width="100%" frameborder="0" scrolling="no"
                                        marginheight="0" marginwidth="0"
                                        src="https://maps.google.com/maps?width=600&amp;height=400&amp;hl=en&amp;q=26.34146033912897, 50.19810002810019&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </section>
        <!-- /Contact-us-->


    </section>
    <!-- main-container -->


    <!--Footer -->
    @include('layouts.includes.frontend.footer1')
    <!-- /Footer-->


</div>


@endsection
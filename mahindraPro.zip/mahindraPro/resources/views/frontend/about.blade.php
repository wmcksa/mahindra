@extends('layouts.app')

@section('title','About Page')
@section('content')

<div class="page-wrapper">


    <!--Header-->
    @include('layouts.includes.frontend.nav')

    <!-- /Header -->


    <section>


        <!--Page Header-->
        <section class="page-header aboutus_page1" style="background-image: url(assets/images/newimage/About.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">من نحن</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="{{url('/')}}">
                                <span id="ContentPlaceHolder_lblHomeHeader">الصفحة الرئيسية</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">من نحن</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->

        </section>
        <!-- /Page Header-->

        <!--About-us-->

        <!-- /About-us-->

        <!-- Why-Choose-Us-->
        <section class="why_choose_us section-padding gray-bg">
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="title">لماذا <span>ماهيندرا</span></h2>
                    <p class="body">
                        <span id="ContentPlaceHolder_lblWhydesc">
                            <p class="MsoListParagraph" dir="RTL" style="margin-top:0in;margin-right:.5in;
margin-bottom:8.0pt;margin-left:0in;mso-add-space:auto;text-align:justify;
direction:rtl;unicode-bidi:embed">
                                <font face="Arial, sans-serif"><span style="font-size: 18.6667px;">مجموعة ماهيندرا
                                        هي اتحاد عالمي للشركات التي تسعى الى تمكين الناس من النهوض والتطور من خلال
                                        حلول مبتكرة صنعت لتقديم تجربة عصرية فريدة من نوعها في عالم التنقل و رعاية
                                        الأعمال التجارية الجديدة وتعزيز المجتمعات. في عام 1945 ، بدأت رحلة ماهيندرا,
                                        وبعد 75 عامًا توسعت لتشمل 23 صناعة رئيسية. تحتل ماهيندرا موقعًا رياديًا في
                                        المركبات متعددة الاستخدامات وتكنولوجيا المعلومات والخدمات المالية وملكية
                                        الإجازات في الهند وهي أكبر شركة جرارات في العالم من حيث الحجم. يقع المقر
                                        الرئيسي لشركة ماهيندرا في الهند ، وتمتد شبكة ماهيندرا ليعمل بها أكثر من
                                        250,000 شخص في 100 دولة حول العالم.</span></font>
                            </p>
                        </span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="listing_box">
                            <h5><i class="fa fa-user-circle" aria-hidden="true"></i>
                                <span id="ContentPlaceHolder_lblTrustedByThousands">موثوق به من قبل الآلاف</span>
                            </h5>
                            <p class="body">
                                <span id="ContentPlaceHolder_lblTrustedByThousandsdesc">بعد شراء سيارات ماهيندرا
                                    يمكنك صيانتها والتاكد من سلامتها في اي وقت من خلال زيارة الشركة</span>
                            </p>
                        </div>
                        <div class="listing_box">
                            <h5><i class="fa fa-globe" aria-hidden="true"></i>
                                <span id="ContentPlaceHolder_lblWideRangeOfVehicles">مجموعة واسعة من الميزات في
                                    المركبات</span>
                            </h5>
                            <p class="body">
                                <span id="ContentPlaceHolder_lblWideRangeOfVehiclesdesc">مع ماهيندرا يمكنك الاستمتاع
                                    بجميع المناظر الخلابة و عيش المغامرة اين ما كان طريقك!</span>

                            </p>
                        </div>
                        <div class="listing_box">
                            <h5><i class="fa fa-car" aria-hidden="true"></i>
                                <span id="ContentPlaceHolder_lblFasterBuySell">دعم ما بعد البيع</span>
                            </h5>
                            <p class="body">
                                <span id="ContentPlaceHolder_lblFasterBuySelldesc">مع الرغبة المتزايدة في امتلاك
                                    السيارات المتميزه وزيادة الطلب على منتجاتنا فيمكنك بسهولة شرائها وبيعها</span>

                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="video_box">
                            <iframe class="mfp-iframe" src="https://www.youtube.com/embed/3Zsyy3JjZME"
                                allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /Why-Choose-Us-->





    </section>
    <!-- main-container -->


    <!--Footer -->

    @include('layouts.includes.frontend.footer1')

    <!-- /Footer-->



</div>

<!-- Scripts -->







@endsection
@extends('layouts.app')

@section('title','Home Page')
@section('content')

<div class="page-wrapper">

    <!--Header-->

    @include('layouts.includes.frontend.nav')

    <!-- /Header -->
    <section>
        <!--Banner-->
        <section id="banner2">
            <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <div class="carousel-item ">
                        <img src="{{asset('assets/Images/ImageSlider/eea9c318-78ea-49cd-8f71-4a72d609049a.png')}}"
                            class="img-fluid" alt="image">
                        <div class="carousel-caption">
                            <div class="banner_text text-center div_zindex white-text">
                                <h1></h1>
                                <h3></h3>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item active">
                        <img src="{{asset('assets/Images/ImageSlider/750051a1-c720-4e71-b644-97a15719a310.png')}}"
                            class="img-fluid" alt="image">
                        <div class="carousel-caption">
                            <div class="banner_text text-center div_zindex white-text">
                                <h1></h1>
                                <h3></h3>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <img src="{{asset('assets/Images/ImageSlider/df8ce1df-6b19-4dcb-9c33-5140cb340903.png')}}"
                            class="img-fluid" alt="image">
                        <div class="carousel-caption">
                            <div class="banner_text text-center div_zindex white-text">
                                <h1></h1>
                                <h3></h3>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item ">
                        <img src="{{asset('assets/Images/ImageSlider/3fbf13f4-31be-4f38-ab55-146f04fed30e.png')}}"
                            class=" img-fluid" alt="image">
                        <div class="carousel-caption">
                            <div class="banner_text text-center div_zindex white-text">
                                <h1></h1>
                                <h3></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Controls -->
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </section>
        <!--/Banner-->
        <!-- Filter-Form -->


        @include('layouts.includes.frontend.cars_filter')


        <!-- /Filter-Form -->
        <!--About-us-->
        <section id="about_us" class="section-padding">
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="title">
                        <span id="ContentPlaceHolder_lblWelcometomahindrauaeuae">مرحبا بكم في ماهيندرا </span>
                    </h2>
                    <p class="body">
                        <span id="ContentPlaceHolder_lblAboutdesc">
                            <p class="MsoListParagraph" dir="RTL" style="margin-top:0in;margin-right:.5in;
margin-bottom:8.0pt;margin-left:0in;mso-add-space:auto;text-align:justify;
direction:rtl;unicode-bidi:embed">
                                <font face="Arial, sans-serif"><span style="font-size: 18.6667px;">مجموعة ماهيندرا
                                        هي اتحاد عالمي للشركات التي تسعى الى تمكين الناس من النهوض والتطور من خلال
                                        حلول مبتكرة صنعت لتقديم تجربة عصرية فريدة من نوعها في عالم التنقل و رعاية
                                        الأعمال التجارية الجديدة وتعزيز المجتمعات. في عام 1945 ، بدأت رحلة ماهيندرا,
                                        وبعد 75 عامًا توسعت لتشمل 23 صناعة رئيسية. تحتل ماهيندرا موقعًا رياديًا في
                                        المركبات متعددة الاستخدامات وتكنولوجيا المعلومات والخدمات المالية وملكية
                                        الإجازات في الهند وهي أكبر شركة جرارات في العالم من حيث الحجم. يقع المقر
                                        الرئيسي لشركة ماهيندرا في الهند ، وتمتد شبكة ماهيندرا ليعمل بها أكثر من
                                        250,000 شخص في 100 دولة حول العالم.</span></font>
                            </p>
                        </span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="about_info">
                            <div class="icon_box">
                                <i class="fa fa-money" aria-hidden="true"></i>
                            </div>
                            <h5>
                                <span id="ContentPlaceHolder_lblBestPrice">افضل الاسعار</span>
                            </h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="about_info">
                            <div class="icon_box">
                                <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
                            </div>
                            <h5>
                                <span id="ContentPlaceHolder_lblFasterBuySell">موثوق به من قبل الآلاف</span>
                            </h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="about_info">
                            <div class="icon_box">
                                <i class="fa fa-history" aria-hidden="true"></i>
                            </div>
                            <h5>
                                <span id="ContentPlaceHolder_lblFreeSupport">دعم ما بعد البيع</span>
                            </h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="about_info">
                            <div class="icon_box">
                                <i class="fa fa-users" aria-hidden="true"></i>
                            </div>
                            <h5>
                                <span id="ContentPlaceHolder_lblProfessionalDealers">عملاء راضون</span>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/About-us-->
        <!--Fan-Fact-->
        <section id="fun-facts" class="dark-bg vc_row">
            <div class=" col-md-6 vc_col section-padding">
                <div class="fact_m white-text ">
                    <h2 class="title">
                        <span id="ContentPlaceHolder_lblMahindraPIKUP">ماهيندرا بيك اب</span>
                    </h2>
                    <p class="body">
                        <span id="ContentPlaceHolder_lblAHEAVENLYVIEW">نظرة ساحرة ...</span>
                        <span id="ContentPlaceHolder_lblATHEAVENLYPRICE">بأسعار مذهلة</span>
                    </p>
                </div>
            </div>

        </section>
    </section>
    <!-- main-container -->
    <!--Footer -->

    @include('layouts.includes.frontend.footer1')
</div>



@endsection
<div>
    <section id="filter_form2">

        <div class="container">

            <div class="main_bg white-text">

                <h3>
                    <span id="ContentPlaceHolder_lblFindYourDreamCar">Find Your Dream Car</span>
                </h3>

                <div>

                    <div class="row">

                        
                        <div class="form-group col-md-3 col-sm-6">
                            <div class="select">
                                <select class="form-control" wire:model.defer="dealer_locator_id">
                                    <option value=""> Select Location </option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $dealerLocators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealerLocator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($dealerLocator->id); ?>">
                                        <?php echo e($dealerLocator->location); ?>

                                    </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option>No Location</option>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </select>

                            </div>

                        </div>


                        
                        <div class="form-group col-md-3 col-sm-6">
                            <div class="select">
                                <select class="form-control" wire:model.defer="model_car_id">
                                    <option>
                                        <span id="ContentPlaceHolder_lblSelectModel">Select Model</span>
                                    </option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $modelCars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelCar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($modelCar->id); ?>"><?php echo e($modelCar->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option>
                                        <span>No Models</span>
                                    </option>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>


                        
                        <div class="form-group col-md-3 col-sm-6">
                            <div class="select">
                                <select class="form-control" wire:model.defer="category_id">
                                    <option> Select category </option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($Category->id); ?>"> <?php echo e($Category->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option>No Categories</option>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        
                        <div class="form-group col-md-3 col-sm-6">
                            <div class="select">
                                <select class="form-control" wire:model.defer="motion_vactor_id">
                                    <option> Motion vector</option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $motionVactor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motionVactorItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($motionVactorItem->id); ?>"> <?php echo e($motionVactorItem->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option>No Motion vector</option>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>

                        
                        <div class="form-group col-md-3 col-sm-6">
                            <div class="select">
                                <select class="form-control" wire:model.defer="engine_id">
                                    <option> Engine type</option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $engines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($engine->id); ?>"><?php echo e($engine->type); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option>No Engine</option>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>


                        
                        <div class="form-group col-md-3 col-sm-6">
                            <div class="select">
                                <select class="form-control" wire:model.defer="year_of_model_id">
                                    <option> Year of Model </option>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $yearOfModeles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearOfModele): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($yearOfModele->id); ?>">
                                        <?php echo e($yearOfModele->year_of_model); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option> No Year Of Model </option>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-6 col-sm-6">
                            <a class="btn btn-block" wire:click="viewCar">
                                
                                <span id="ContentPlaceHolder_lblSearchCar">Search Car</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>











    
</div><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/livewire/frontend/en/car-filter.blade.php ENDPATH**/ ?>
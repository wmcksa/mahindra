<?php $__env->startSection('title','Dealer Locator Page'); ?>
<?php $__env->startSection('content'); ?>


<div class="page-wrapper">

    <!--Header-->
    <?php echo $__env->make('layouts.includes.frontend.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Header -->


    <section>



        <!--Page Header-->
        <section class="page-header aboutus_page"
            style="background-image: url(assets/images/newimage/DealerLocator.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">فروعنا</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="<?php echo e(url('/')); ?>">
                                <span id="ContentPlaceHolder_lblHomeHeader">الصفحة الرئيسية</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">فروعنا</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->

        </section>
        <!-- /Page Header-->

        <!--Contact-us-->
        <section class="contact_us section-padding">
            <div class="container">

                <div class="row">
                    <div class="col-md-6">
                        <h3 class="title">
                            <span id="ContentPlaceHolder_lblMahindra">ماهيندرا</span>
                        </h3>
                        <div class="contact_form gray-bg">
                            <?php $__empty_1 = true; $__currentLoopData = $dealerlocators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealerlocator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <ul style="list-style: none;" class="body">
                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lbladdress1">
                                            <?php echo e($dealerlocator->country); ?>

                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="contact_info_m">
                                        <?php echo e($dealerlocator->city); ?>

                                    </div>
                                </li>
                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lbladdress2">
                                            <?php echo e($dealerlocator->location); ?>

                                        </span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class="contact_info_m">

                                        <span id="ContentPlaceHolder_lblSun">
                                            أيام العمل
                                            <?php echo e($dealerlocator->beginning_working_day); ?>

                                            الى
                                            <?php echo e($dealerlocator->end_working_day); ?>


                                        </span>
                                    </div>
                                </li>

                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lblSatCLOSED">

                                            ساعات العمل
                                            <?php echo e($dealerlocator->beginning_working_hours); ?>

                                            الى
                                            <?php echo e($dealerlocator->end_working_hours); ?>

                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="contact_info_m"><a href="<?php echo e($dealerlocator->mobile); ?>">
                                            <?php echo e($dealerlocator->mobile); ?>

                                        </a></div>
                                </li>

                            </ul>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <div>
                                <h2>لا يوجد فروع </h2>
                            </div>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="contact_detail">
                            <div class="map_wrap">
                                <div class="mapouter">
                                    <iframe class="gmap_iframe" width="100%" frameborder="0" scrolling="no"
                                        marginheight="0" marginwidth="0"
                                        src="https://maps.google.com/maps?width=600&amp;height=400&amp;hl=en&amp;q=26.34146033912897, 50.19810002810019&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </section>
        <!-- /Contact-us-->


    </section>
    <!-- main-container -->


    <!--Footer -->
    <?php echo $__env->make('layouts.includes.frontend.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Footer-->


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/frontend/dealerlocator.blade.php ENDPATH**/ ?>
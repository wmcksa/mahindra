<?php $__env->startSection('title','Dealer Locator Page'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-wrapper">

    <!--Header-->

    <?php echo $__env->make('layouts.includes.frontend.en.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Header -->


    <section>



        <!--Page Header-->
        <section class="page-header aboutus_page"
            style="background-image: url(assets/images/newimage/DealerLocator.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">Dealer Locator</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="<?php echo e(url('/home-en')); ?>">
                                <span id="ContentPlaceHolder_lblHomeHeader">Home</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">Dealer Locator</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->

        </section>
        <!-- /Page Header-->

        <!--Contact-us-->
        <section class="contact_us section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h3 class="title">
                            <span id="ContentPlaceHolder_lblMahindra">Mahindra</span>
                        </h3>
                        <div class="contact_form gray-bg">
                            <?php $__empty_1 = true; $__currentLoopData = $dealerlocators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealerlocator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <ul style="list-style: none;" class="body">
                                <li>
                                    <div class="contact_info_m">
                                        <?php echo e($dealerlocator->country); ?>

                                </li>
                                <li>
                                    <?php echo e($dealerlocator->city); ?> </li>
                                <li>
                                    <div class="contact_info_m">
                                        <?php echo e($dealerlocator->location); ?> </div>
                                </li>

                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lblSun">Working Days:
                                            <?php echo e($dealerlocator->beginning_working_day); ?>

                                            To
                                            <?php echo e($dealerlocator->end_working_day); ?>

                                        </span>
                                    </div>
                                </li>

                                <li>
                                    <div class="contact_info_m">
                                        <span id="ContentPlaceHolder_lblSatCLOSED">Working Hours:
                                            <?php echo e($dealerlocator->beginning_working_hours); ?>

                                            To
                                            <?php echo e($dealerlocator->end_working_hours); ?>

                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="contact_info_m"><a href="<?php echo e($dealerlocator->mobile); ?>">
                                            <?php echo e($dealerlocator->mobile); ?> </a>
                                    </div>
                                </li>

                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <div>
                                <h2>
                                    No Dealer Locator
                                </h2>
                            </div>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="contact_detail">
                            <div class="map_wrap">
                                <div class="mapouter">
                                    <iframe class="gmap_iframe" width="100%" frameborder="0" scrolling="no"
                                        marginheight="0" marginwidth="0"
                                        src="https://maps.google.com/maps?width=600&amp;height=400&amp;hl=en&amp;q=26.34146033912897, 50.19810002810019&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /Contact-us-->


    </section>
    <!-- main-container -->


    <!--Footer -->
    <?php echo $__env->make('layouts.includes.frontend.en.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- /Footer-->




</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_en', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/frontend/en/dealerlocator.blade.php ENDPATH**/ ?>
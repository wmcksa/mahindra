<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.en.car-filter', []);

$__html = app('livewire')->mount($__name, $__params, 'CG7EmDg', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/layouts/includes/frontend/en/cars_filter.blade.php ENDPATH**/ ?>
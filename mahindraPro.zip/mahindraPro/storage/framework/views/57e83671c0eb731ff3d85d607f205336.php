<?php $__env->startSection('title','Contact Us Page'); ?>
<?php $__env->startSection('content'); ?>



<div class="page-wrapper">
    <!--Header-->
    <?php echo $__env->make('layouts.includes.frontend.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Header -->


    <section>

        <!--Page Header-->
        <section class="page-header contactus_page" style="background-image: url(assets/images/newimage/Contact.png);">
            <div class="container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">اتصل بنا</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="<?php echo e(url('/')); ?>">
                                <span id="ContentPlaceHolder_lblHomeHeader">الصفحة الرئيسية</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">اتصل بنا</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->
            <div class="dark-overlay"></div>
        </section>
        <!-- /Page Header-->

        <!--Contact-us-->

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.vehicles-detail.contact', []);

$__html = app('livewire')->mount($__name, $__params, 'Ll3Ha2w', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <!-- /Contact-us-->

        <!--Brands-->

        <!-- /Brands-->


    </section>
    <!-- main-container -->

    <!--Footer -->
    <?php echo $__env->make('layouts.includes.frontend.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- /Footer-->




</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/frontend/contact.blade.php ENDPATH**/ ?>
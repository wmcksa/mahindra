<?php $__env->startSection('title','Cars Page'); ?>

<?php $__env->startSection('content'); ?>


<div class="page-wrapper">

    <?php echo $__env->make('layouts.includes.frontend.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section>
        <!--Page Header-->
        <section class="page-header aboutus_page"
            style="background-image: url(<?php echo e(asset('assets/images/newimage/Vehicles.png')); ?>);">
            <div class=" container">
                <div class="page-header_wrap">
                    <div class="page-heading">
                        <h1>
                            <span id="ContentPlaceHolder_lblTitleHeader">السيارات</span>
                        </h1>
                    </div>
                    <ul class="coustom-breadcrumb">
                        <li><a href="<?php echo e(url('/')); ?>">
                                <span id="ContentPlaceHolder_lblHomeHeader">الصفحة الرئيسية</span></a></li>
                        <li>
                            <span id="ContentPlaceHolder_lblTitleHeader2">السيارات</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Dark Overlay-->
        </section>
        <!-- /Page Header-->

        <!--Listing-grid-view-->
        <section class="listing-page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-md-push-3">
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-4 grid_listing">
                                <div class="product-listing-m gray-bg">
                                    <div class="product-listing-img">
                                        
                                        <a href="<?php echo e(url('/VehiclesDetail/' . $category->id)); ?>">
                                            
                                        </a>
                                    </div>

                                    
                                    <div class="product-listing-content">
                                        <h5><a href="<?php echo e(url('/VehiclesDetail/' . $category->id)); ?>">
                                                <?php echo e($category->name); ?>

                                            </a>
                                        </h5>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="product-listing-m gray-bg">
                                <div class="product-listing-content">
                                    <h5><a href='VehiclesDetail.aspx?ID=1'>
                                            <?php echo e('لا يوجد فئات '); ?>

                                        </a></h5>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/Listing-grid-view-->
    </section>
    <!-- main-container -->


    <!--Footer -->

    <?php echo $__env->make('layouts.includes.frontend.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



</div>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/frontend/viewCategory.blade.php ENDPATH**/ ?>
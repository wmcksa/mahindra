<div>
    <section>
        <div class="container">
            <div class="main_bg white-text">
                <h3>
                    <span>ابحث عن سيارة أحلامك</span>
                </h3>
                <div>
                    <div class="row">
                        
                            <div class="form-group col-md-3 col-sm-6">
                                <div class="select">
                                    <select class="form-control" wire:model.defer="dealer_locator_id">
                                        <option value="">
                                            <span>اختر الفرع</span>
                                        </option>
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $dealerLocators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealerLocator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($dealerLocator->id); ?>">
                                            <span><?php echo e($dealerLocator->location); ?></span>
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option>
                                            <span>لا يوجد فروع</span>
                                        </option>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                                    </select>
                                </div>
                            </div>

                            
                            <div class="form-group col-md-3 col-sm-6">
                                <div class="select">
                                    <select class="form-control" wire:model.defer="model_car_id">
                                        <option>
                                            <span>نوع السيارة</span>
                                        </option>

                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $modelCars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelCar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($modelCar->id); ?>">
                                            <span><?php echo e($modelCar->name); ?>

                                            </span>
                                        </option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option>
                                            <span>لا يوجد أنواع</span>
                                        </option>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                                    </select>
                                </div>
                            </div>

                            <div class="form-group col-md-3 col-sm-6">
                                <div class="select">
                                    <select class="form-control" wire:model.defer="category_id">
                                        <option>
                                            <span>حدد الفئة</span>
                                        </option>

                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($Category->id); ?>"> <?php echo e($Category->name); ?> </option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option> لا يوجد فئات </option>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                                    </select>
                                </div>
                            </div>

                            
                            <div class="form-group col-md-3 col-sm-6">
                                <div class="select">
                                    <select class="form-control" wire:model.defer="motion_vactor_id">

                                        <option> ناقل الحركة</option>
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $motionVactor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motionVactorItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($motionVactorItem->id); ?>"> <?php echo e($motionVactorItem->name); ?> </option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option> لا يوجد نواقل حركة </option>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </div>
                            </div>

                            
                            <div class="form-group col-md-3 col-sm-6">
                                <div class="select">
                                    <select class="form-control" wire:model.defer="engine_id">
                                        <option> نوع المحرك</option>
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $engines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($engine->id); ?>"><?php echo e($engine->type); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option> لا يوجد محركات </option>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </div>
                            </div>

                            
                            <div class="form-group col-md-3 col-sm-6">
                                <div class="select">
                                    <select class="form-control" wire:model.defer="year_of_model_id">
                                        <option>
                                            <span>سنة الصنع</span>
                                        </option>
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $yearOfModeles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearOfModele): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($yearOfModele->id); ?>">
                                            <?php echo e($yearOfModele->year_of_model); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option>
                                            لا يوجد سنة
                                        </option>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </div>
                            </div>

                            <div class="form-group col-md-6 col-sm-6">
                                
                                    <a class="btn btn-block" wire:click="viewCar">
                                        
                                        <span>عرض السيارة</span>
                                    </a>
                            </div>

                            
                    </div>
                </div>
            </div>
        </div>
    </section>



    

</div><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/livewire/frontend/car-filter.blade.php ENDPATH**/ ?>
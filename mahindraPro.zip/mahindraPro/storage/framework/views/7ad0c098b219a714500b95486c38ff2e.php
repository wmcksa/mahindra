<header class="header_style2 nav-stacked affix-top" data-spy="affix" data-offset-top="1">
    <!-- Navigation -->
    <nav id="navigation_bar" class="navbar navbar-expand-lg">
        <div class="container custom-con">
            <div class="row header-row padding-remove">
                <div class="navbar-header">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>">
                            

                            <?php if($appSetting->site_logo): ?>
                            <img src="<?php echo e(asset('storage/' . $appSetting->site_logo  )); ?>" width="200" />
                            <?php else: ?>
                            <img src="<?php echo e(asset('assets/images/logo/Mahindra-Logo_Red.png')); ?>" width="200" />
                            <?php endif; ?>
                        </a>
                    </div>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
                </div>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="<?php echo e(url('/')); ?>">
                                <span id="lblHome">الصفحة الرئيسية</span></a>
                        </li>
                        <li><a href="<?php echo e(url('/about')); ?>">
                                <span id="lblAboutMenu">معلومات عن الشركة</span></a></li>
                        <li><a href="<?php echo e(url('/vehicles')); ?>">
                                <span id="lblVehicles">السيارات</span>
                            </a></li>
                        <li><a href="<?php echo e(url('/dealerlocator')); ?>">
                                <span id="lblDealerLocator">فروعنا</span></a></li>
                        <li><a href="<?php echo e(url('/contact')); ?>">
                                <span id="lblContactMenu">اتصل بنا</span></a></li>

                        <li id="liLang" style="display: none">
                            <a id="A1" href="<?php echo e(url('/home-en')); ?>">
                                <span id="Label1">English</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="header_wrap margin-remove">
                    <div class="login_btn">
                        <a id="lbChangeLang" class="btn btn-xs uppercase" href="<?php echo e(url('/home-en')); ?>">
                            <span id="lbllang">English</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!--
Navigation end -->


</header><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/layouts/includes/frontend/nav.blade.php ENDPATH**/ ?>
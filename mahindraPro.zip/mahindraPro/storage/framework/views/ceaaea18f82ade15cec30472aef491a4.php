<?php $__env->startSection('title','Cars Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <!--Header-->
    <?php echo $__env->make('layouts.includes.frontend.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Header -->


    <section>

        <style type="text/css">
            #container {
                margin: auto;
                bottom: 0;
                left: 0;
                /*top: 0;*/
                right: 0;
                width: 200px;
                height: 119px;
                font: normal 18px Arial, Helvetica, sans-serif;
                line-height: 450px;
                text-align: center;
                color: white;
                overflow: hidden;
                cursor: pointer;
            }

            /*.modal-body {
            margin: auto;
            bottom: 0;
            left: 0;*/
            /* top: 0;*/
            /*right: 0;
            width: fit-content;
            height: fit-content;
            font: normal 18px Arial, Helvetica, sans-serif;
            line-height: 450px;
            text-align: center;
            color: white;
            overflow: hidden;
            cursor: pointer;
        }*/

            #spinImg {
                position: absolute;
                left: 0;
                /*top: 0;*/
                width: 7200px;
                height: 119px;
                visibility: hidden;
                border: none;
            }

            /* @media (min-width: 576px) {
            .modal-dialog {
                max-width: max-content;
                margin: 1.75rem auto;
            }
        }*/
        </style>

        <!--Listing-Image-Slider-->
        <section id="listing_img_slider">

            <?php $__empty_1 = true; $__currentLoopData = $feature->car_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div>
                <img src="<?php echo e(asset('storage/' . $image)); ?>" width="506" height="315" class="img-fluid" alt="image">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div>
                <h2>NO Image</h2>
            </div>
            <?php endif; ?>

            

        </section>
        <!--/Listing-Image-Slider-->

        <section class="listing_other_info secondary-bg">
            <div class="container">

                <div id="other_info"><i class="fa fa-info-circle" aria-hidden="true"></i></div>
                <div id="info_toggle">
                    <button type="button" data-bs-toggle="modal" data-bs-target="#schedule">
                        <i class="fa fa-car" aria-hidden="true"></i>
                        جدولة اختبار القيادة
                    </button>
                    <button type="button" data-bs-toggle="modal" data-bs-target="#make_offer">
                        <i class="fa fa-money" aria-hidden="true"></i>
                        طلب عرض
                    </button>

                    <button type="button" data-bs-toggle="modal" data-bs-target="#more_info">
                        <i class="fa fa-file-text-o" aria-hidden="true"></i>
                        طلب مزيد من المعلومات
                    </button>

                    <button type="button" data-bs-toggle="modal" data-bs-target="#miantenanec_time">
                        <i class="fa fa-file-text-o" aria-hidden="true"></i>
                        حجز موعد صيانة
                    </button>



                    <button type="button" data-bs-toggle="modal" data-bs-target="#View360" style="display: none;">
                        <i class="fa fa-file-text-o" aria-hidden="true"></i>
                        360°
                    </button>
                </div>
            </div>
        </section>
        <!--Listing-detail-->
        <section class="listing-detail">
            <div class="container">
                <div class="listing_detail_head row">
                    <div class="col-md-12">
                        <h3 class="title">
                            
                            <span id="ContentPlaceHolder_lblProductName">
                                <?php echo e($category->name); ?>

                            </span>
                        </h3>

                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="main_features">
                            <p>
                                <span id="ContentPlaceHolder_lblDesc">
                                    <div><br></div>
                                </span>
                            </p>

                        </div>
                        <div class="listing_more_info">
                            <div class="listing_detail_wrap">
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    


                                    <li class="nav-item" role="presentation"><a class="nav-link active" id="home-tab"
                                            data-bs-toggle="tab" href="#home" role="tab" aria-controls="home"
                                            aria-selected="true"><?php echo e($category->name); ?> </a>
                                    </li>


                                    <li class="nav-item" role="presentation"><a class="nav-link" id="Accessories-tab"
                                            data-bs-toggle="tab" href="#Accessories" role="tab"
                                            aria-controls="Accessories" aria-selected="true">Accessories</a></li>
                                </ul>

                                <!-- Tab panes -->
                                <div class="tab-content" id="myTabContent">
                                    <!-- vehicle-overview -->
                                    <div role="tabpanel" class="tab-pane active" id="home" aria-labelledby="home-tab">
                                        <div class="table-responsive">

                                            <input type="hidden"
                                                name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl00$hfSpecificationIdSingle"
                                                id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_0"
                                                value="1" />
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <!-- المواصفات التقنية  -->
                                                        <th colspan="2">TECHINICAL SPECIFICATIONS</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>شعبية</td>
                                                        <td><?php echo e($feature->traction ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>الإطارات</td>
                                                        <td><?php echo e($feature->tyres ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>محرك</td>
                                                        <td><?php echo e($feature->engine ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>عزم الدوران</td>
                                                        <td><?php echo e($feature->torque ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>انتقال</td>
                                                        <td><?php echo e($feature->transmission ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>التروس</td>
                                                        <td><?php echo e($feature->gears ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>عجلات</td>
                                                        <td><?php echo e($feature->wheels ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>البعد (الطول × العرض × الارتفاع)</td>
                                                        <td><?php echo e($feature->dismension_LXWXH ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>أبعاد صندوق الأمتعة (الطول × العرض × الارتفاع)</td>
                                                        <td><?php echo e($feature->cargo_box_dimension_LXWXH ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>زاوية</td>
                                                        <td><?php echo e($feature->angle ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>تطهير الأرض</td>
                                                        <td><?php echo e($feature->ground_clearance ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>وزن إجمالي وزن المركبة</td>
                                                        <td><?php echo e($feature->GVW ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>تطويق</td>
                                                        <td><?php echo e($feature->kerb ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>دفع حمولة</td>
                                                        <td><?php echo e($feature->pay_load ??''); ?></td>
                                                    </tr>


                                                </tbody>
                                            </table>

                                            <input type="hidden"
                                                name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl01$hfSpecificationIdSingle"
                                                id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_1"
                                                value="2" />
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <!-- الامان  -->
                                                        <th colspan="2">Safety</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>أكياس هواء أمامية مزدوجة</td>
                                                        <td><?php echo e($feature->dual_front_AIR_bags ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>عمود توجيه قابل للانهيار</td>
                                                        <td><?php echo e($feature->collapsible_steering_column ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>تنجيد مقاوم للحريق</td>
                                                        <td><?php echo e($feature->fire_retardant_upholstery ??''); ?></td>
                                                    </tr>


                                                </tbody>
                                            </table>

                                            <input type="hidden"
                                                name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl02$hfSpecificationIdSingle"
                                                id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_2"
                                                value="3" />
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <!-- الراحة -->
                                                        <th colspan="2">Comfort</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>تكييف</td>
                                                        <td><?php echo e($feature->AIR_conditoning ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>قيادة</td>
                                                        <td><?php echo e($feature->steering_control ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>المرآة الخلفية</td>
                                                        <td><?php echo e($feature->rear_view_mirror ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>برنامج تشغيل WINDOW CONTROL بلمسة واحدة - والمبرمج (مضاد
                                                            للقرص)</td>
                                                        <td><?php echo e($feature->one_touch_window_control_driver_codriver_antipinch
                                                            ??''); ?>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>اتبعني المصابيح الأمامية</td>
                                                        <td><?php echo e($feature->follow_me_homw_headlamps ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>يستريح الذراع على المقاعد الأمامية</td>
                                                        <td><?php echo e($feature->ARM_rest_on_front_seats ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>عجلات من سبائك</td>
                                                        <td><?php echo e($feature->alloy_wheels ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>اختياري</td>
                                                        <td><?php echo e($feature->optional ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>شاشة تعمل باللمس متكاملة نظام المعلومات والترفيه الملاحة
                                                            عبر الأقمار الصناعية</td>
                                                        <td><?php echo e($feature->touch_screen_intregated_infotainment_satellite_navigation
                                                            ??''); ?>

                                                        </td>
                                                    </tr>


                                                </tbody>
                                            </table>

                                            <input type="hidden"
                                                name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl03$hfSpecificationIdSingle"
                                                id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_3"
                                                value="4" />
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <!-- مميزات اخرى  -->
                                                        <th colspan="2">OTHER FEATURE</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>مصباح الرأس</td>
                                                        <td><?php echo e($feature->headlamp ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>أقواس بونيه هيدروليكيه</td>
                                                        <td><?php echo e($feature->hydraulic_bonnet_struts ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>المقعد الخلفي</td>
                                                        <td><?php echo e($feature->rear_demister ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>غني بالأسود</td>
                                                        <td><?php echo e($feature->rich_black ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>جهاز عرض مزود بمصابيح حواجب</td>
                                                        <td><?php echo e($feature->projector_with_EYR_brow_lamps ??''); ?></td>
                                                    </tr>



                                                </tbody>
                                            </table>

                                            <input type="hidden"
                                                name="ctl00$ContentPlaceHolder$rptSpecificationSingle$ctl04$hfSpecificationIdSingle"
                                                id="ContentPlaceHolder_rptSpecificationSingle_hfSpecificationIdSingle_4"
                                                value="5" />
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <!-- الاسلوب  -->
                                                        <th colspan="2">Style</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <tr>
                                                        <td>مقابض أبواب مطلية</td>
                                                        <td><?php echo e($feature->painted_door_handles ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>مصد أمامي مطلي</td>
                                                        <td><?php echo e($feature->painted_front_bumber ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>الكسوة</td>
                                                        <td><?php echo e($feature->claddings ??''); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <td>رسم</td>
                                                        <td><?php echo e($feature->painted ??''); ?></td>
                                                    </tr>


                                                </tbody>
                                            </table>

                                        </div>
                                    </div>


                                    <!-- Accessories -->
                                    <div role="tabpanel" class="tab-pane" id="Accessories"
                                        aria-labelledby="Accessories-tab">
                                        <!--Accessories-->
                                        <div class="container">
                                            <div class="dealers_list_wrap">
                                                <?php $__empty_1 = true; $__currentLoopData = $feature->accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-3 col-xs-4">
                                                            <div class="dealer_logo">
                                                                <a href="<?php echo e(asset('storage/' . $image)); ?>"
                                                                    target="_blank">
                                                                    <img src="<?php echo e(asset('storage/' . $image)); ?>"
                                                                        alt="image">
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> </h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <div class="dealers_listing">
                                                    <div class="row">
                                                        <div class="col-sm-6 col-xs-8">
                                                            <div class="dealer_info">
                                                                <h5> No accessories</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
</section>

<!--View360 -->
<!--View360 -->
<div class="modal fade" id="View360">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">
                    360°</h3>
            </div>
            <div class="modal-body">
                <!--Listing-detail-->
                <section class="listing-detail" style="padding: 0;">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="listing_more_info" style="padding: 0;">
                                    <div class="listing_detail_wrap">
                                        <!-- Nav tabs -->
                                        <ul class="nav nav-tabs" id="myTab1" role="tablist">
                                            <li class="nav-item" role="presentation"><a class="nav-link active"
                                                    id="EXTERIOR-tab" data-bs-toggle="tab" href="#EXTERIOR" role="tab"
                                                    aria-controls="EXTERIOR" aria-selected="true">الخارج
                                                </a></li>
                                            <li class="nav-item" role="presentation"><a class="nav-link"
                                                    id="INTERIOR-tab" data-bs-toggle="tab" href="#INTERIOR" role="tab"
                                                    aria-controls="INTERIOR" aria-selected="true">الداخلية</a></li>
                                        </ul>
                                        <!-- Tab panes -->
                                        <div class="tab-content" id="myTabContent1">
                                            <!-- vehicle-overview -->
                                            <div role="tabpanel" class="tab-pane active" id="EXTERIOR"
                                                aria-labelledby="EXTERIOR-tab">
                                                <div id="container" onselectstart="return false;">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </div>
</div>
<!--/View360 -->
<!--/View360 -->

<script>
    window.onload = function() {
                        var imageTotal = 36,
                            clicked = false,
                            widthStep = 10,
                            currPos, currImg = 0;
                        var imageLeft = 0;
                        imageWidth = $('#spinImg').width(), imageFrame = $('#container').width();
                        $('#spinImg').css('visibility', 'visible');
                        $("#View360").on('mousedown touchstart', function(e) {
                            currPos = (e.type == "touchstart") ? window.event.touches[0].pageX : e.pageX;
                            clicked = true;
                            return false;
                        }); // end mousedown

                        $("#View360").on('mouseup touchend', function() {
                            clicked = false;
                        }).on('mousemove touchmove', function(e) {
                            if (clicked) {
                                var pageX = (e.type == "touchmove") ? window.event.targetTouches[0].pageX : e.pageX;
                                if (Math.abs(currPos - pageX) >= widthStep) {
                                    if (currPos - pageX >= widthStep) {
                                        currImg++;
                                        imageLeft = imageLeft - imageFrame;
                                        if (currImg >= imageTotal) {
                                            currImg = 1;
                                            imageLeft = 0;
                                        }
                                    } else {
                                        currImg--;
                                        imageLeft = imageLeft + imageFrame;
                                        if (imageLeft > 0) {
                                            currImg = imageTotal, imageLeft = -imageWidth + imageFrame
                                        }
                                    }
                                    $('#spinImg').css('left', imageLeft + 'px');
                                    currPos = pageX;
                                }
                            } // end clicked
                        }); // end mousemove
                    }; //end load
</script>


</section>
<!-- main-container -->


<!--Footer -->

<?php echo $__env->make('layouts.includes.frontend.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- /Footer-->


<!--Schedule-Test-Drive -->

<div class="modal fade" id="schedule">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.vehicles-detail.test-drive', []);

$__html = app('livewire')->mount($__name, $__params, 'NQ2xumM', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div> 
<!--/Schedule-Test-Drive -->

<!--Make-Offer -->
<div class="modal fade" id="make_offer">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.vehicles-detail.offer', []);

$__html = app('livewire')->mount($__name, $__params, '6SvAx5m', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
<!--/Make-Offer -->

<!--Request-More-Info -->
<div class="modal fade" id="more_info">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.vehicles-detail.request-more', []);

$__html = app('livewire')->mount($__name, $__params, 'jvAkypM', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
<!--/Request-More-Info -->



<div class="modal fade" id="miantenanec_time">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.vehicles-detail.miantenanec-time', []);

$__html = app('livewire')->mount($__name, $__params, 'bTAjpHy', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>


</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/frontend/VehiclesDetail.blade.php ENDPATH**/ ?>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.car-filter', []);

$__html = app('livewire')->mount($__name, $__params, 'f4lUb3H', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/layouts/includes/frontend/cars_filter.blade.php ENDPATH**/ ?>
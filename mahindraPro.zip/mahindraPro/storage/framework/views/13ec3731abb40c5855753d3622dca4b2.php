<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">




    <!--Header-->
    <?php echo $__env->make('layouts.includes.frontend.en.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- /Header -->


    <section>




        <!--Banner-->

        <section id="banner2">

            <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">

                <!-- Wrapper for slides -->

                <div class="carousel-inner">



                    <div class="carousel-item ">

                        <img src="<?php echo e(asset('assets/Images/ImageSlider/eea9c318-78ea-49cd-8f71-4a72d609049a.png')); ?>"
                            class="img-fluid" alt="image">


                        <div class="carousel-caption">

                            <div class="banner_text text-center div_zindex white-text">

                                <h1></h1>

                                <h3></h3>

                            </div>

                        </div>

                    </div>

                    <div class="carousel-item active">

                        <img src="<?php echo e(asset('assets/Images/ImageSlider/750051a1-c720-4e71-b644-97a15719a310.png')); ?>"
                            class="
                                img-fluid" alt="image">


                        <div class="carousel-caption">

                            <div class="banner_text text-center div_zindex white-text">

                                <h1></h1>

                                <h3></h3>

                            </div>

                        </div>

                    </div>

                    <div class="carousel-item ">

                        <img src=" <?php echo e(asset('assets/Images/ImageSlider/df8ce1df-6b19-4dcb-9c33-5140cb340903.png')); ?>"
                            class=" img-fluid" alt="image">


                        <div class="carousel-caption">

                            <div class="banner_text text-center div_zindex white-text">

                                <h1></h1>

                                <h3></h3>

                            </div>

                        </div>

                    </div>

                    <div class="carousel-item ">

                        <img src="<?php echo e(asset('assets/Images/ImageSlider/3fbf13f4-31be-4f38-ab55-146f04fed30e.png')); ?>"
                            class="
                                img-fluid" alt="image">


                        <div class="carousel-caption">

                            <div class="banner_text text-center div_zindex white-text">

                                <h1></h1>

                                <h3></h3>

                            </div>

                        </div>

                    </div>







                </div>



                <!-- Controls -->

                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="prev">

                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>

                    <span class="visually-hidden">Previous</span>

                </button>

                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                    data-bs-slide="next">

                    <span class="carousel-control-next-icon" aria-hidden="true"></span>

                    <span class="visually-hidden">Next</span>

                </button>

            </div>

        </section>

        <!--/Banner-->

        <!-- Filter-Form -->

        <?php echo $__env->make('layouts.includes.frontend.en.cars_filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- /Filter-Form -->





        <!--About-us-->

        <section id="about_us" class="section-padding">

            <div class="container">

                <div class="section-header text-center">

                    <h2 class="title">
                        <span id="ContentPlaceHolder_lblWelcometomahindrauaeuae">Welcome to mahindra</span>
                    </h2>

                    <p class="body">
                        <span id="ContentPlaceHolder_lblAboutdesc">
                            <font color="#726d7b" face="DM Sans, sans-serif"><span style="font-size: 18px;">The
                                    Mahindra Group is a global consortium of companies that empowers people to
                                    advance and develop through innovative solutions designed to deliver a unique
                                    modern mobility experience, nurture new businesses and enhance communities. In
                                    1945, Mahindra's journey began, and 75 years later it has expanded to cover 23
                                    major industries. Mahindra is a leader in utility vehicles, information
                                    technology, financial services and vacation ownership in India and is the
                                    world's largest tractor company by volume. Headquartered in India, Mahindra's
                                    network employs more than 250,000 people in 100 countries around the
                                    world.</span></font>
                        </span>

                    </p>

                </div>



                <div class="row">

                    <div class="col-md-3 col-sm-6">

                        <div class="about_info">

                            <div class="icon_box">

                                <i class="fa fa-money" aria-hidden="true"></i>

                            </div>

                            <h5>
                                <span id="ContentPlaceHolder_lblBestPrice">Best Price</span>
                            </h5>



                        </div>

                    </div>



                    <div class="col-md-3 col-sm-6">

                        <div class="about_info">

                            <div class="icon_box">

                                <i class="fa fa-thumbs-o-up" aria-hidden="true"></i>

                            </div>

                            <h5>
                                <span id="ContentPlaceHolder_lblFasterBuySell">Trusted By Thousands</span>
                            </h5>



                        </div>

                    </div>



                    <div class="col-md-3 col-sm-6">

                        <div class="about_info">

                            <div class="icon_box">

                                <i class="fa fa-history" aria-hidden="true"></i>

                            </div>

                            <h5>
                                <span id="ContentPlaceHolder_lblFreeSupport">Aftersales Support</span>
                            </h5>



                        </div>

                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="about_info">
                            <div class="icon_box">
                                <i class="fa fa-users" aria-hidden="true"></i>
                            </div>
                            <h5>
                                <span id="ContentPlaceHolder_lblProfessionalDealers">Satisfied Customers</span>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/About-us-->



        <!--Fan-Fact-->

        <section id="fun-facts" class="dark-bg vc_row">
            <div class=" col-md-6 vc_col section-padding">
                <div class="fact_m white-text">
                    <h2 class="title">
                        <span id="ContentPlaceHolder_lblMahindraPIKUP">Mahindra PIK UP</span>
                    </h2>
                    <p class="body">
                        <span id="ContentPlaceHolder_lblAHEAVENLYVIEW">A HEAVENLY VIEW … </span>
                        <span id="ContentPlaceHolder_lblATHEAVENLYPRICE">AT HEAVENLY PRICE.</span>
                    </p>
                </div>
            </div>
        </section>

        <!--/Fan-fact-->
















        <!--Blog -->

        <section class="section-padding" style="display:none;">

            <div class="container">

                <div class="section-header text-center">

                    <h2>
                        <span id="ContentPlaceHolder_lblLatest">Latest Updates In Automobile Industry </span>
                    </h2>

                    <p>
                        <span id="ContentPlaceHolder_lblLatestDesc">
                            There are many variations of passages of Lorem Ipsum available, but the majority have
                            suffered alteration in some form, by injected humour, or randomised words which don't
                            look even slightly believable. If you are going to use a passage of Lorem Ipsum, you
                            need to be sure there isn't anything embarrassing hidden in the middle of text.
                        </span>

                    </p>

                </div>

                <div class="row">

                    <div class="col-md-4 col-sm-4">

                        <article class="blog-list">

                            <div class="blog-info-box">


                                <img src="<?php echo e(asset('assets/Images/NEWS/cad967b5-1fdf-4a6a-b179-d4fa83e7982f.jpg')); ?>"
                                    class="
                                        img-fluid" alt="image">


                                <ul>



                                    <li><i class="fa fa-calendar" aria-hidden="true"></i>8/19/2022</li>


                                </ul>

                            </div>

                            <div class="blog-content">

                                <h5><a>MANAGING SOCIAL MEDIA PLATFORMS.</a></h5>

                                <p>
                                    <span
                                        style="color: rgb(114, 109, 123); font-family: &quot;DM Sans&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">We
                                        manage accounts to show your presence and represent you as required
                                        according to various content plans</span>
                                </p>


                            </div>

                        </article>

                    </div>

                    <div class="col-md-4 col-sm-4">

                        <article class="blog-list">

                            <div class="blog-info-box">


                                <img src="<?php echo e(asset('assets/Images/NEWS/b25b0c16-125e-4fb2-880c-f0d368aac763.jpg')); ?>"
                                    class="
                                        img-fluid" alt="image">


                                <ul>



                                    <li><i class="fa fa-calendar" aria-hidden="true"></i>8/19/2022</li>


                                </ul>

                            </div>

                            <div class="blog-content">

                                <h5><a>BUILDING A VISUAL IDENTITY</a></h5>

                                <p>
                                    <span
                                        style="color: rgb(114, 109, 123); font-family: &quot;DM Sans&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">We
                                        create the visual presence of your company through elements associated with
                                        the logo, products and services of the brand or facility you
                                        represent</span>
                                </p>


                            </div>

                        </article>

                    </div>

                    <div class="col-md-4 col-sm-4">

                        <article class="blog-list">

                            <div class="blog-info-box">


                                <img src="<?php echo e(asset('assets/Images/NEWS/16ee4f6c-f03f-49a1-a435-df2ab91746c4.jpg')); ?>"
                                    class="
                                        img-fluid" alt="image">


                                <ul>



                                    <li><i class="fa fa-calendar" aria-hidden="true"></i>8/19/2022</li>


                                </ul>

                            </div>

                            <div class="blog-content">

                                <h5><a>MEDIA RESEARCH AND PUBLIC OPINION STUDIES</a></h5>

                                <p>
                                    <span
                                        style="color: rgb(114, 109, 123); font-family: &quot;DM Sans&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">We
                                        present research and studies according to steps and tactics that are
                                        consistent with a scientific perspective</span>
                                </p>


                            </div>

                        </article>

                    </div>

                    <div class="col-md-4 col-sm-4">

                        <article class="blog-list">

                            <div class="blog-info-box">


                                <img src="<?php echo e(asset('assets/Images/NEWS/435c5aee-2610-48fd-971e-f2d6c3972785.jpg')); ?>"
                                    class="
                                        img-fluid" alt="image">


                                <ul>



                                    <li><i class="fa fa-calendar" aria-hidden="true"></i>8/19/2022</li>


                                </ul>

                            </div>

                            <div class="blog-content">

                                <h5><a>MANAGING COMMUNICATIONS CAMPAIGNS</a></h5>

                                <p>
                                    <span
                                        style="color: rgb(114, 109, 123); font-family: &quot;DM Sans&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">We
                                        define the target audience, develop communication messages, produce
                                        appropriate content, and define dissemination channels</span>
                                </p>


                            </div>

                        </article>

                    </div>

                    <div class="col-md-4 col-sm-4">

                        <article class="blog-list">

                            <div class="blog-info-box">


                                <img src="<?php echo e(asset('assets/Images/NEWS/88415ba8-f23c-40ec-94ec-6df6e12a8398.jpg')); ?>"
                                    class="
                                        img-fluid" alt="image">


                                <ul>



                                    <li><i class="fa fa-calendar" aria-hidden="true"></i>8/19/2022</li>


                                </ul>

                            </div>

                            <div class="blog-content">

                                <h5><a>CONTENT INDUSTRY</a></h5>

                                <p>
                                    <span
                                        style="color: rgb(114, 109, 123); font-family: &quot;DM Sans&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">We
                                        sail in the imagination to create innovative and modern content that meets
                                        the requirements of the client</span>
                                </p>


                            </div>

                        </article>

                    </div>

                    <div class="col-md-4 col-sm-4">

                        <article class="blog-list">

                            <div class="blog-info-box">


                                <img src="<?php echo e(asset('assets/Images/NEWS/08c6015e-5d8f-4415-b046-94a3d658bfe3.jpg')); ?>"
                                    class="
                                        img-fluid" alt="image">


                                <ul>



                                    <li><i class="fa fa-calendar" aria-hidden="true"></i>8/19/2022</li>


                                </ul>

                            </div>

                            <div class="blog-content">

                                <h5><a>MEDIA MONITORING AND ANALYSIS</a></h5>

                                <p>
                                    <span
                                        style="color: rgb(114, 109, 123); font-family: &quot;DM Sans&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">We
                                        monitor and analyze what is circulating on social media platforms and
                                        present them in organized reports to be used in planning or measuring public
                                        opinion trends.</span>
                                </p>


                            </div>

                        </article>

                    </div>

                    <div class="col-md-4 col-sm-4">

                        <article class="blog-list">

                            <div class="blog-info-box">


                                <img src="<?php echo e(asset('assets/Images/NEWS/45fdb324-d1c2-49d4-89d0-405672f8270b.jpg')); ?>"
                                    class="img-fluid" alt="image">


                                <ul>



                                    <li><i class="fa fa-calendar" aria-hidden="true"></i>8/19/2022</li>


                                </ul>

                            </div>

                            <div class="blog-content">
                                <h5><a>STRATEGIC PLANNING</a></h5>
                                <p>
                                    <span
                                        style="color: rgb(114, 109, 123); font-family: &quot;DM Sans&quot;, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);">We
                                        build and develop strategic plans for our clients in line with their vision
                                        and goals</span>
                                </p>
                            </div>
                        </article>

                    </div>




                </div>
            </div>
        </section>

        <!-- /Blog-->





    </section>
    <!-- main-container -->


    <!--Footer -->

    <?php echo $__env->make('layouts.includes.frontend.en.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- /Footer-->


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_en', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/frontend/en/index.blade.php ENDPATH**/ ?>
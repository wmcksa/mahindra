<div>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">
                    <span id="lblScheduleTestDrive">Schedule Test Drive</span>
                </h3>
            </div>
            <div class="modal-body">
                
                    <div class="py-3 py-md-12">
                        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?>

                        </div>
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
                        <div class="alert alert-wrong">
                            <?php echo e(session('error')); ?>

                        </div>
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                    </div>
                    <div class="form-group">
                        <input wire:model.defer="name" type="text" id="fullName" class="form-control"
                            placeholder="Full Name" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group">
                        <input wire:model.defer="email" type="email" id="Email" class="form-control"
                            placeholder="Email address" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group">
                        <input wire:model.defer="phone" type="text" id="Phone" class="form-control" placeholder="Phone"
                            required />
                    </div>
                    <div class="form-group">
                        <input wire:model.defer="date" type="datetime-local" id="BestTime" class="form-control"
                            placeholder="Best Time (00:00am)" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="form-group" hidden>

                        <input name="form_type" id="ContentPlaceHolder_message"
                            class="form-control custom-height white_bg" rows="4" value="2">
                    </div>

                    <div class="form-group">
                        <textarea wire:model.defer="message" id="Message" rows="4" class="form-control"
                            placeholder="Message" required></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group">
                        <button type="submit" wire:click="Save" class="btn btn-block">
                            Submit
                        </button>
                    </div>
                    
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/livewire/frontend/en/vehicles-detail/test-drive.blade.php ENDPATH**/ ?>
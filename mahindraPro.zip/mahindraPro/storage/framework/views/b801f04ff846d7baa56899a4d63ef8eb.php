<?php $__env->startSection('title','About Page'); ?>
<?php $__env->startSection('content'); ?>



<h2>welcome</h2>



<script type="text/javascript">
    (function(){

            var options={
                facebook:"01808281208101",
                instagram:"Ishithemes",
                call_to_action:"We are aonline",
                button_color:"#932c8B",
                position:"right",
                order:"faccebook,instagram",
            };

            var proto = document.location.protocol, host="getbutton.io", url = proto + "//static." + host;

            var s = document.createElement('script'); s.type ='text/javascript'; s.async = true; s.src = url+
            '/widget-send-button/js/init.js';
            s.onload = function() { WhWidgetSendButton.init(host, proto, options);};
            var x=document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
        });

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/frontend/share.blade.php ENDPATH**/ ?>
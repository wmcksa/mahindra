<div>
    <div class="modal fade" id="make_offer">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title">
                        <span id="lblMakeanOffer">طلب عرض</span>
                    </h3>
                </div>
                <div class="modal-body">
                    <form action="Post.php" method="POST">
                        <div class="form-group">
                            <input name="name" type="text" id="FullNamemake_offer" class="form-control"
                                placeholder="السم بلكامل" required />
                        </div>
                        <div class="form-group">
                            <input name="email" type="email" id="EmailAddressmake_offer" class="form-control"
                                placeholder="بريدك الالكتروني" required />
                        </div>
                        <div class="form-group">
                            <input name="phone" type="text" id="PhoneNumbermake_offer" class="form-control"
                                placeholder="رقم الهاتف" required />
                        </div>
                        <div class="form-group">
                            <input name="price" type="number" id="OfferPricemake_offer" class="form-control"
                                placeholder="سعر العرض" required />
                        </div>
                        <div class="form-group">
                            <textarea name="message" id="Messageemake_offer" class="form-control" placeholder="الرسالة"
                                required></textarea>

                        </div>


                        <div class="form-group" hidden>
                            <input name="form_type" type="text" class="form-control" placeholder="" value="3" />
                        </div>



                        <div class="form-group">
                            <input name="" type="submit" id="Submitmake_offer" value="ارسال" class="btn btn-block" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravel\mahindraPro\resources\views/livewire/frontend/vehicles-detail/request-offer.blade.php ENDPATH**/ ?>
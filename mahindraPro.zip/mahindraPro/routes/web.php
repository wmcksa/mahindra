<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/', [App\Http\Controllers\Frontend\FrontendController::class, 'index']); //عرض الصفحة الرئيسية
Route::get('/about', [App\Http\Controllers\Frontend\FrontendController::class, 'about']);
Route::get('/vehicles', [App\Http\Controllers\Frontend\FrontendController::class, 'vehicles']); //عرض السيارات
Route::get('/contact', [App\Http\Controllers\Frontend\FrontendController::class, 'contact']); //عرض صفحة تواصل معنا
Route::get('/VehiclesDetail/{category_id}', [App\Http\Controllers\Frontend\FrontendController::class, 'VehiclesDetail']); //عرض معلومات السيارةالمحددة
Route::get('/viewCategory/{car_id}', [App\Http\Controllers\Frontend\FrontendController::class, 'viewCategory']); //عرض انواع السيارةالمحددة
Route::get('/dealerlocator', [App\Http\Controllers\Frontend\FrontendController::class, 'dealerlocator']); //عرض صفحة فروعنا



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//frontenfenglish
Route::get('/home-en', [App\Http\Controllers\Frontend\en\FrontendController::class, 'index']); //عرض الصفحة الرئيسية
Route::get('/about-en', [App\Http\Controllers\Frontend\en\FrontendController::class, 'about']);
Route::get('/vehicles-en', [App\Http\Controllers\Frontend\en\FrontendController::class, 'vehicles']); //عرض السيارات
Route::get('/contact-en', [App\Http\Controllers\Frontend\en\FrontendController::class, 'contact']); //عرض صفحة تواصل معنا
Route::get('/VehiclesDetail-en/{category_id}', [App\Http\Controllers\Frontend\en\FrontendController::class, 'VehiclesDetail']); //عرض معلومات السيارةالمحددة
Route::get('/viewCategory-en/{car_id}', [App\Http\Controllers\Frontend\en\FrontendController::class, 'viewCategory']); //عرض انواع السيارةالمحددة
Route::get('/dealerlocator-en', [App\Http\Controllers\Frontend\en\FrontendController::class, 'dealerlocator']);//عرض صفحة فروعنا
